# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compound-interactions.spec.ts >> narrow-dark-rtl >> investigation forwards evidence selection with result lineage
- Location: tests/visual/compound-interactions.spec.ts:190:9

# Error details

```
Error: expect(received).toMatchObject(expected)

Matcher error: received value must be a non-null object

Received has value: null

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=e2]:
  - heading "Investigation" [level=1] [ref=e3]
  - region "Investigation" [ref=e7]:
    - generic [ref=e8]:
      - heading "Investigation" [level=2] [ref=e9]
      - generic [ref=e10]: Authorized people
    - generic [ref=e11]:
      - region "Trend" [ref=e12]:
        - heading "Trend" [level=3] [ref=e13]
        - figure "Data visualization" [ref=e15]:
          - paragraph [ref=e17]: Complete result. 3 loaded rows.
          - region "Data visualization trend chart. Scroll to view the full graphic." [ref=e18]:
            - img "Data visualization. Complete result. Values and selection are available in the data table below." [ref=e19]:
              - generic "2026-09-08" [ref=e25]
              - generic "2026-09-09" [ref=e26]
              - generic "2026-09-10" [ref=e27]
              - generic "96" [ref=e28]
              - generic "120" [ref=e29]
              - generic "144" [ref=e30]
              - generic [ref=e31]: Date
              - generic [ref=e32]: Amount
          - table [ref=e34]:
            - caption [ref=e35]: "Data visualization: Exact loaded values"
            - rowgroup [ref=e36]:
              - row [ref=e37]:
                - columnheader "Select" [ref=e38]
                - columnheader "ID" [ref=e39]
                - columnheader "Name" [ref=e40]
                - columnheader "Team" [ref=e41]
                - columnheader "Date" [ref=e42]
                - columnheader "Amount" [ref=e43]
                - columnheader "Bin start" [ref=e44]
                - columnheader "Bin end" [ref=e45]
                - columnheader "Baseline" [ref=e46]
            - rowgroup [ref=e47]:
              - row [ref=e48]:
                - cell [ref=e49]:
                  - button "Select ada" [ref=e50]: Select
                - cell "ada" [ref=e51]
                - cell "Ada Lovelace" [ref=e52]
                - cell "Research" [ref=e53]
                - cell "2026-09-08" [ref=e54]
                - cell "120" [ref=e55]
                - cell "80" [ref=e56]
                - cell "100" [ref=e57]
                - cell "0" [ref=e58]
              - row [ref=e59]:
                - cell [ref=e60]:
                  - button "Select lin" [ref=e61]: Select
                - cell "lin" [ref=e62]
                - cell "Lin Chen" [ref=e63]
                - cell "Product" [ref=e64]
                - cell "2026-09-09" [ref=e65]
                - cell "96" [ref=e66]
                - cell "100" [ref=e67]
                - cell "140" [ref=e68]
                - cell "0" [ref=e69]
              - row [ref=e70]:
                - cell [ref=e71]:
                  - button "Select grace" [ref=e72]: Select
                - cell "grace" [ref=e73]
                - cell "Grace Hopper" [ref=e74]
                - cell "Research" [ref=e75]
                - cell "2026-09-10" [ref=e76]
                - cell "144" [ref=e77]
                - cell "140" [ref=e78]
                - cell "160" [ref=e79]
                - cell "0" [ref=e80]
      - region "Baseline" [ref=e81]:
        - heading "Baseline" [level=3] [ref=e82]
        - generic [ref=e84]:
          - term [ref=e85]: Baseline
          - definition [ref=e86]:
            - generic [ref=e87]: "100"
      - region "Event timeline" [ref=e88]:
        - heading "Event timeline" [level=3] [ref=e89]
        - paragraph [ref=e90]: No events are available.
      - generic [ref=e91]:
        - heading "Detail" [level=3] [ref=e92]
        - region "Investigation detail" [ref=e94]:
          - heading "Investigation detail" [level=2] [ref=e96]
          - generic [ref=e97]:
            - generic [ref=e98]:
              - term [ref=e99]: ID
              - definition [ref=e100]: ada
            - generic [ref=e101]:
              - term [ref=e102]: Name
              - definition [ref=e103]: Ada Lovelace
            - generic [ref=e104]:
              - term [ref=e105]: Team
              - definition [ref=e106]: Research
            - generic [ref=e107]:
              - term [ref=e108]: Date
              - definition [ref=e109]: 2026-09-08
            - generic [ref=e110]:
              - term [ref=e111]: Amount
              - definition [ref=e112]: "120"
          - paragraph [ref=e113]: Authorized people; 3 of 3 matching records loaded
    - paragraph [ref=e114]: Associations are displayed as evidence in the selected scope. They do not establish causal claims.
```

# Test source

```ts
  95  |     (element as HTMLElement & Record<string, unknown>)[change.property] = change.value;
  96  |     await (element as HTMLElement & {updateComplete?: Promise<unknown>}).updateComplete;
  97  |   }, {property, value});
  98  | }
  99  | 
  100 | async function capture(session: ReviewSession, page: Page, info: TestInfo, label: string): Promise<void> {
  101 |   const axe = await new AxeBuilder({page}).analyze();
  102 |   await info.attach(`${label}-accessibility.json`, {
  103 |     body: JSON.stringify({violations: axe.violations, incomplete: axe.incomplete}, null, 2),
  104 |     contentType: "application/json",
  105 |   });
  106 |   await info.attach(`${label}-environment.json`, {
  107 |     body: JSON.stringify({
  108 |       id: session.id,
  109 |       variant: session.variant,
  110 |       browser: page.context().browser()?.version(),
  111 |       project: info.project.name,
  112 |       viewport: await page.evaluate(() => ({width: innerWidth, height: innerHeight, dpr: devicePixelRatio})),
  113 |       direction: await page.evaluate(() => document.documentElement.dir),
  114 |       events: await page.evaluate(() => (window as ReviewWindow).compoundInteractionEvents ?? []),
  115 |     }, null, 2),
  116 |     contentType: "application/json",
  117 |   });
  118 |   await page.screenshot({path: info.outputPath(`${label}.png`), fullPage: true});
  119 |   expect(session.errors).toEqual([]);
  120 |   expect(axe.violations.map(({id, impact, nodes}) => ({id, impact, nodes: nodes.map(({target, failureSummary}) => ({target, failureSummary}))}))).toEqual([]);
  121 | }
  122 | 
  123 | for (const variant of variants) {
  124 |   test.describe(variant, () => {
  125 |     test("explorer commits an authorized filter and stable identity selection", async ({page}, info) => {
  126 |       const session = await openCompound(page, "explorer", variant);
  127 |       const filter = session.host.locator("aeliqo-filter-builder");
  128 |       if (await filter.locator("[part=clause]").count() === 0) {
  129 |         await filter.getByRole("button", {name: "Add condition", exact: true}).click();
  130 |       }
  131 |       const condition = filter.locator("[part=clause]").first();
  132 |       await condition.locator("[part=field]").selectOption("name");
  133 |       await condition.locator("[part=value]").fill("Ada");
  134 |       await filter.locator("[part=apply]").click();
  135 |       await expect.poll(() => lastEvent(page, "aeliqo-explorer-filter")).toMatchObject({
  136 |         predicate: {op: "compare", entity: "person", field: "name", comparison: "eq", value: "Ada"},
  137 |         applied: true,
  138 |       });
  139 | 
  140 |       await session.host.getByRole("button", {name: "Select person lin", exact: true}).click();
  141 |       await expect.poll(() => lastEvent(page, "aeliqo-explorer-selection")).toMatchObject({
  142 |         mode: "ids",
  143 |         entity: "person",
  144 |         keys: ["string:3:lin"],
  145 |         result: {id: "aeliqo-catalog-example", outputId: "people"},
  146 |         scope: {populationDigest: "catalog-scope"},
  147 |       });
  148 |       await capture(session, page, info, "explorer-interaction");
  149 |     });
  150 | 
  151 |     test("comparison emits a bounded set and exposes incompatible metrics", async ({page}, info) => {
  152 |       const session = await openCompound(page, "comparison", variant);
  153 |       await session.host.getByRole("button", {name: "Ada", exact: true}).click();
  154 |       await expect.poll(() => lastEvent(page, "aeliqo-comparison-set")).toMatchObject({
  155 |         source: "user",
  156 |         entity: "person",
  157 |         keys: ["grace"],
  158 |         result: {id: "aeliqo-catalog-example"},
  159 |         scope: {label: "Authorized people"},
  160 |       });
  161 | 
  162 |       await setHostProperty(session.host, "compatible", false);
  163 |       await expect(session.host.locator('[part="status"][role="alert"]')).toContainText("cannot be compared");
  164 |       await expect(session.host.locator('[part="compare-button"]')).toHaveCount(0);
  165 |       await capture(session, page, info, "comparison-incompatible");
  166 | 
  167 |       await setHostProperty(session.host, "compatible", true);
  168 |       await session.host.getByRole("button", {name: "Grace", exact: true}).click();
  169 |       await expect.poll(() => lastEvent(page, "aeliqo-comparison-set")).toMatchObject({keys: ["ada"]});
  170 |       await capture(session, page, info, "comparison-interaction");
  171 |     });
  172 | 
  173 |     test("breakdown emits the selected group identity without deriving a metric", async ({page}, info) => {
  174 |       const session = await openCompound(page, "breakdown", variant);
  175 |       const table = session.host.locator("aeliqo-table");
  176 |       await table.locator('input[type="radio"]').first().check();
  177 |       await expect.poll(() => lastEvent(page, "aeliqo-breakdown-group")).toMatchObject({
  178 |         source: "user",
  179 |         entity: "person",
  180 |         key: "research",
  181 |         result: {id: "aeliqo-catalog-example"},
  182 |         scope: {label: "Authorized people"},
  183 |       });
  184 | 
  185 |       await setHostProperty(session.host, "selectedGroup", "research");
  186 |       await expect(session.host.locator('[part="detail"]')).toContainText("Ada Lovelace");
  187 |       await capture(session, page, info, "breakdown-interaction");
  188 |     });
  189 | 
  190 |     test("investigation forwards evidence selection with result lineage", async ({page}, info) => {
  191 |       const session = await openCompound(page, "investigation", variant);
  192 |       const trend = session.host.locator("aeliqo-trend");
  193 |       await expect(trend.locator('[part="data"] button').first()).toBeVisible();
  194 |       await trend.locator('[part="data"] button').first().click();
> 195 |       await expect.poll(() => lastEvent(page, "aeliqo-visualization-select")).toMatchObject({
      |                                                                               ^ Error: expect(received).toMatchObject(expected)
  196 |         source: "user",
  197 |         identity: JSON.stringify([JSON.stringify(["text", "ada"])]),
  198 |         result: {id: "aeliqo-catalog-example", outputId: "people"},
  199 |       });
  200 |       await expect(session.host.locator('[part="caution"]')).toContainText("do not establish causal claims");
  201 |       await capture(session, page, info, "investigation-selection");
  202 |     });
  203 | 
  204 |     test("search results restore a matching revision before emitting selection", async ({page}, info) => {
  205 |       const session = await openCompound(page, "search-results", variant);
  206 |       await expect(session.host.locator('[part="status"][role="status"]')).toContainText("out of date");
  207 |       await session.host.evaluate(async (element) => {
  208 |         const host = element as HTMLElement & {queryRevision: string; resultRevision: string; updateComplete: Promise<unknown>};
  209 |         host.resultRevision = host.queryRevision;
  210 |         await host.updateComplete;
  211 |       });
  212 |       await expect(session.host.locator("aeliqo-card-collection")).toBeAttached();
  213 |       await session.host.locator('aeliqo-card-collection [part="card-button"]').first().click();
  214 |       await expect.poll(() => lastEvent(page, "aeliqo-search-results-selection")).toMatchObject({
  215 |         mode: "ids",
  216 |         entity: "person",
  217 |         keys: ["string:3:ada"],
  218 |         result: {id: "aeliqo-catalog-example"},
  219 |         scope: {label: "Authorized people"},
  220 |       });
  221 |       await capture(session, page, info, "search-results-selection");
  222 |     });
  223 | 
  224 |     test("record editor keeps an IME draft and emits explicit save and cancel receipts", async ({page}, info) => {
  225 |       const session = await openCompound(page, "record-editor", variant);
  226 |       const editor = session.host;
  227 |       const field = editor.locator("aeliqo-text-field");
  228 |       const input = field.locator('input[part="input"]');
  229 |       const save = editor.getByRole("button", {name: "Save", exact: true});
  230 |       const cancel = editor.getByRole("button", {name: "Cancel", exact: true});
  231 | 
  232 |       await field.evaluate(async (element) => {
  233 |         const control = element as HTMLElement & {validationState: string; updateComplete: Promise<unknown>};
  234 |         control.validationState = "pending";
  235 |         await control.updateComplete;
  236 |       });
  237 |       await expect(field.locator('[part="pending"][role="status"]')).toHaveText("Checking…");
  238 | 
  239 |       await setHostProperty(editor, "disabled", true);
  240 |       await expect(save).toBeDisabled();
  241 |       await expect(cancel).toBeDisabled();
  242 |       await setHostProperty(editor, "disabled", false);
  243 |       await setHostProperty(editor, "invalid", true);
  244 |       await expect(save).toBeDisabled();
  245 |       await setHostProperty(editor, "invalid", false);
  246 |       await setHostProperty(editor, "status", "loading");
  247 |       await expect(editor.locator('[part="status"][role="status"]')).toContainText("Loading authorized data");
  248 |       await setHostProperty(editor, "status", "ready");
  249 |       await field.evaluate(async (element) => {
  250 |         const control = element as HTMLElement & {validationState: string; updateComplete: Promise<unknown>};
  251 |         control.validationState = "idle";
  252 |         await control.updateComplete;
  253 |       });
  254 | 
  255 |       await input.focus();
  256 |       await input.evaluate((element) => {
  257 |         const native = element as HTMLInputElement;
  258 |         native.dispatchEvent(new CompositionEvent("compositionstart", {bubbles: true}));
  259 |         native.value = "Ada IME draft";
  260 |         native.dispatchEvent(new InputEvent("input", {bubbles: true, isComposing: true, inputType: "insertCompositionText", data: "Ada IME draft"}));
  261 |       });
  262 |       await expect(input).toHaveValue("Ada IME draft");
  263 |       await field.evaluate(async (element) => {
  264 |         const control = element as HTMLElement & {label: string; updateComplete: Promise<unknown>};
  265 |         control.label = "Updated name";
  266 |         await control.updateComplete;
  267 |       });
  268 |       await expect(input).toBeFocused();
  269 |       await input.evaluate((element) => element.dispatchEvent(new CompositionEvent("compositionend", {bubbles: true, data: "Ada IME draft"})));
  270 |       await expect.poll(() => input.inputValue()).toBe("Ada IME draft");
  271 | 
  272 |       await save.click();
  273 |       await expect.poll(() => lastEvent(page, "aeliqo-record-editor-save")).toMatchObject({
  274 |         source: "user",
  275 |         entity: "person",
  276 |         key: "string:3:ada",
  277 |         entityRevision: "person-revision-1",
  278 |         values: {name: "Ada IME draft", "period[start]": "2026-09-01", "period[end]": "2026-09-30"},
  279 |       });
  280 |       await cancel.click();
  281 |       await expect.poll(() => lastEvent(page, "aeliqo-record-editor-cancel")).toMatchObject({
  282 |         source: "user",
  283 |         key: "string:3:ada",
  284 |         entityRevision: "person-revision-1",
  285 |         values: {name: "Ada IME draft"},
  286 |       });
  287 |       await capture(session, page, info, "record-editor-interaction");
  288 |     });
  289 | 
  290 |     test("form flow validates before moving, preserves draft and focus, then commits", async ({page}, info) => {
  291 |       const session = await openCompound(page, "form-flow", variant);
  292 |       const flow = session.host;
  293 |       const input = flow.locator("aeliqo-text-field").locator('input[part="input"]');
  294 |       await flow.evaluate((element) => {
  295 |         const host = element as HTMLElement & {activeStep: string; addEventListener: HTMLElement["addEventListener"]};
```