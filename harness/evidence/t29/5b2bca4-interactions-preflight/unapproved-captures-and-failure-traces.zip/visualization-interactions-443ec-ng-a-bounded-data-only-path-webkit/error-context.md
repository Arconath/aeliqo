# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visualization-interactions.spec.ts >> tree narrow-dark-rtl paginates 30 rows while retaining a bounded data-only path
- Location: tests/visual/visualization-interactions.spec.ts:270:9

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('#fixture aeliqo-tree').first().locator('tbody tr')
Expected: 5
Received: 25
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('#fixture aeliqo-tree').first().locator('tbody tr') with timeout 5000ms
  - waiting for locator('#fixture aeliqo-tree').first().locator('tbody tr')
    14 × locator resolved to 25 elements
       - unexpected value "25"

```

# Page snapshot

```yaml
- main [ref=e2]:
  - heading "Tree" [level=1] [ref=e3]
  - figure "Catalog example" [ref=e7]:
    - paragraph [ref=e9]: Complete result. 30 loaded rows.
    - status [ref=e10]: The hierarchy exceeds the configured mark budget or readable graphic density. Exact values remain available in the data table.
    - 'region "Catalog example: scrollable data" [ref=e11]':
      - table [ref=e12]:
        - caption [ref=e13]: Exact loaded hierarchy data
        - rowgroup [ref=e14]:
          - row [ref=e15]:
            - columnheader "Select" [ref=e16]
            - columnheader "ID" [ref=e17]
            - columnheader "Parent" [ref=e18]
            - columnheader "Label" [ref=e19]
            - columnheader "Amount" [ref=e20]
        - rowgroup [ref=e21]:
          - row [ref=e22]:
            - cell [ref=e23]:
              - button "Select row [\"[\\\"text\\\",\\\"root\\\"]\"]" [ref=e24]: Select
            - cell "root" [ref=e25]
            - cell "Missing" [ref=e26]
            - cell "Root" [ref=e27]
            - cell "30" [ref=e28]
          - row [ref=e29]:
            - cell [ref=e30]:
              - button "Select row [\"[\\\"text\\\",\\\"node-1\\\"]\"]" [ref=e31]: Select
            - cell "node-1" [ref=e32]
            - cell "root" [ref=e33]
            - cell "Node 1" [ref=e34]
            - cell "1" [ref=e35]
          - row [ref=e36]:
            - cell [ref=e37]:
              - button "Select row [\"[\\\"text\\\",\\\"node-2\\\"]\"]" [ref=e38]: Select
            - cell "node-2" [ref=e39]
            - cell "root" [ref=e40]
            - cell "Node 2" [ref=e41]
            - cell "2" [ref=e42]
          - row [ref=e43]:
            - cell [ref=e44]:
              - button "Select row [\"[\\\"text\\\",\\\"node-3\\\"]\"]" [ref=e45]: Select
            - cell "node-3" [ref=e46]
            - cell "root" [ref=e47]
            - cell "Node 3" [ref=e48]
            - cell "3" [ref=e49]
          - row [ref=e50]:
            - cell [ref=e51]:
              - button "Select row [\"[\\\"text\\\",\\\"node-4\\\"]\"]" [ref=e52]: Select
            - cell "node-4" [ref=e53]
            - cell "root" [ref=e54]
            - cell "Node 4" [ref=e55]
            - cell "4" [ref=e56]
          - row [ref=e57]:
            - cell [ref=e58]:
              - button "Select row [\"[\\\"text\\\",\\\"node-5\\\"]\"]" [ref=e59]: Select
            - cell "node-5" [ref=e60]
            - cell "root" [ref=e61]
            - cell "Node 5" [ref=e62]
            - cell "5" [ref=e63]
          - row [ref=e64]:
            - cell [ref=e65]:
              - button "Select row [\"[\\\"text\\\",\\\"node-6\\\"]\"]" [ref=e66]: Select
            - cell "node-6" [ref=e67]
            - cell "root" [ref=e68]
            - cell "Node 6" [ref=e69]
            - cell "6" [ref=e70]
          - row [ref=e71]:
            - cell [ref=e72]:
              - button "Select row [\"[\\\"text\\\",\\\"node-7\\\"]\"]" [ref=e73]: Select
            - cell "node-7" [ref=e74]
            - cell "root" [ref=e75]
            - cell "Node 7" [ref=e76]
            - cell "7" [ref=e77]
          - row [ref=e78]:
            - cell [ref=e79]:
              - button "Select row [\"[\\\"text\\\",\\\"node-8\\\"]\"]" [ref=e80]: Select
            - cell "node-8" [ref=e81]
            - cell "root" [ref=e82]
            - cell "Node 8" [ref=e83]
            - cell "8" [ref=e84]
          - row [ref=e85]:
            - cell [ref=e86]:
              - button "Select row [\"[\\\"text\\\",\\\"node-9\\\"]\"]" [ref=e87]: Select
            - cell "node-9" [ref=e88]
            - cell "root" [ref=e89]
            - cell "Node 9" [ref=e90]
            - cell "9" [ref=e91]
          - row [ref=e92]:
            - cell [ref=e93]:
              - button "Select row [\"[\\\"text\\\",\\\"node-10\\\"]\"]" [ref=e94]: Select
            - cell "node-10" [ref=e95]
            - cell "root" [ref=e96]
            - cell "Node 10" [ref=e97]
            - cell "10" [ref=e98]
          - row [ref=e99]:
            - cell [ref=e100]:
              - button "Select row [\"[\\\"text\\\",\\\"node-11\\\"]\"]" [ref=e101]: Select
            - cell "node-11" [ref=e102]
            - cell "root" [ref=e103]
            - cell "Node 11" [ref=e104]
            - cell "11" [ref=e105]
          - row [ref=e106]:
            - cell [ref=e107]:
              - button "Select row [\"[\\\"text\\\",\\\"node-12\\\"]\"]" [ref=e108]: Select
            - cell "node-12" [ref=e109]
            - cell "root" [ref=e110]
            - cell "Node 12" [ref=e111]
            - cell "12" [ref=e112]
          - row [ref=e113]:
            - cell [ref=e114]:
              - button "Select row [\"[\\\"text\\\",\\\"node-13\\\"]\"]" [ref=e115]: Select
            - cell "node-13" [ref=e116]
            - cell "root" [ref=e117]
            - cell "Node 13" [ref=e118]
            - cell "13" [ref=e119]
          - row [ref=e120]:
            - cell [ref=e121]:
              - button "Select row [\"[\\\"text\\\",\\\"node-14\\\"]\"]" [ref=e122]: Select
            - cell "node-14" [ref=e123]
            - cell "root" [ref=e124]
            - cell "Node 14" [ref=e125]
            - cell "14" [ref=e126]
          - row [ref=e127]:
            - cell [ref=e128]:
              - button "Select row [\"[\\\"text\\\",\\\"node-15\\\"]\"]" [ref=e129]: Select
            - cell "node-15" [ref=e130]
            - cell "root" [ref=e131]
            - cell "Node 15" [ref=e132]
            - cell "15" [ref=e133]
          - row [ref=e134]:
            - cell [ref=e135]:
              - button "Select row [\"[\\\"text\\\",\\\"node-16\\\"]\"]" [ref=e136]: Select
            - cell "node-16" [ref=e137]
            - cell "root" [ref=e138]
            - cell "Node 16" [ref=e139]
            - cell "16" [ref=e140]
          - row [ref=e141]:
            - cell [ref=e142]:
              - button "Select row [\"[\\\"text\\\",\\\"node-17\\\"]\"]" [ref=e143]: Select
            - cell "node-17" [ref=e144]
            - cell "root" [ref=e145]
            - cell "Node 17" [ref=e146]
            - cell "17" [ref=e147]
          - row [ref=e148]:
            - cell [ref=e149]:
              - button "Select row [\"[\\\"text\\\",\\\"node-18\\\"]\"]" [ref=e150]: Select
            - cell "node-18" [ref=e151]
            - cell "root" [ref=e152]
            - cell "Node 18" [ref=e153]
            - cell "18" [ref=e154]
          - row [ref=e155]:
            - cell [ref=e156]:
              - button "Select row [\"[\\\"text\\\",\\\"node-19\\\"]\"]" [ref=e157]: Select
            - cell "node-19" [ref=e158]
            - cell "root" [ref=e159]
            - cell "Node 19" [ref=e160]
            - cell "19" [ref=e161]
          - row [ref=e162]:
            - cell [ref=e163]:
              - button "Select row [\"[\\\"text\\\",\\\"node-20\\\"]\"]" [ref=e164]: Select
            - cell "node-20" [ref=e165]
            - cell "root" [ref=e166]
            - cell "Node 20" [ref=e167]
            - cell "20" [ref=e168]
          - row [ref=e169]:
            - cell [ref=e170]:
              - button "Select row [\"[\\\"text\\\",\\\"node-21\\\"]\"]" [ref=e171]: Select
            - cell "node-21" [ref=e172]
            - cell "root" [ref=e173]
            - cell "Node 21" [ref=e174]
            - cell "21" [ref=e175]
          - row [ref=e176]:
            - cell [ref=e177]:
              - button "Select row [\"[\\\"text\\\",\\\"node-22\\\"]\"]" [ref=e178]: Select
            - cell "node-22" [ref=e179]
            - cell "root" [ref=e180]
            - cell "Node 22" [ref=e181]
            - cell "22" [ref=e182]
          - row [ref=e183]:
            - cell [ref=e184]:
              - button "Select row [\"[\\\"text\\\",\\\"node-23\\\"]\"]" [ref=e185]: Select
            - cell "node-23" [ref=e186]
            - cell "root" [ref=e187]
            - cell "Node 23" [ref=e188]
            - cell "23" [ref=e189]
          - row [ref=e190]:
            - cell [ref=e191]:
              - button "Select row [\"[\\\"text\\\",\\\"node-24\\\"]\"]" [ref=e192]: Select
            - cell "node-24" [ref=e193]
            - cell "root" [ref=e194]
            - cell "Node 24" [ref=e195]
            - cell "24" [ref=e196]
    - navigation "Visualization data pages" [ref=e197]:
      - button "Previous" [disabled] [ref=e198]
      - generic [ref=e199]: Rows 1–25 of 30
      - button "Next" [ref=e200]
    - paragraph [ref=e201]: The loaded data is available in the table. Selection buttons are keyboard accessible.
```

# Test source

```ts
  179 |   if (id === "hierarchy") {
  180 |     return Array.from({length: count}, (_, index) => index === 0
  181 |       ? {id: "root", parent: null, label: "Root", amount: count}
  182 |       : {id: `node-${index}`, parent: "root", label: `Node ${index}`, amount: index});
  183 |   }
  184 |   return Array.from({length: count}, (_, index) => {
  185 |     const date = new Date(Date.UTC(2026, 8, 1 + index)).toISOString().slice(0, 10);
  186 |     return {
  187 |       id: `row-${index}`,
  188 |       name: `Person ${index}`,
  189 |       team: index % 2 === 0 ? "Research" : "Product",
  190 |       date,
  191 |       amount: index + 1,
  192 |       low: index,
  193 |       high: index + 1,
  194 |       zero: 0,
  195 |     };
  196 |   });
  197 | }
  198 | 
  199 | async function setBoundedRows(host: Locator, id: "trend" | "timeline" | "tree"): Promise<void> {
  200 |   const rows = rowsFor(id === "tree" ? "hierarchy" : id === "timeline" ? "temporal" : "cartesian", 30);
  201 |   await host.evaluate(async (element, nextRows) => {
  202 |     const view = element as VisualizationHost;
  203 |     const result = view.context.results[0]!;
  204 |     view.context = {
  205 |       ...view.context,
  206 |       results: view.context.results.map((candidate, index) => index === 0
  207 |         ? {...candidate, counts: {...(candidate as unknown as {readonly counts: Record<string, unknown>}).counts, loaded: nextRows.length}}
  208 |         : candidate),
  209 |     } as VisualizationHost["context"];
  210 |     view.datasets = [{result: result.ref, rows: nextRows}];
  211 |     view.maxMarks = 1;
  212 |     await view.updateComplete;
  213 |   }, rows);
  214 | }
  215 | 
  216 | for (const variant of VARIANTS) {
  217 |   test.describe(`${variant} visualization interactions`, () => {
  218 |     for (const id of VISUALIZATIONS) {
  219 |       test(`${id} selects a stable identity with exact result lineage`, async ({page}) => {
  220 |         const session = await openVisualization(page, id, variant);
  221 |         const {identity, result, rowText, reorderedIndex} = expectedSelection[id];
  222 |         const button = session.host.locator("[part=data] tbody button").first();
  223 |         await expect(button).toBeVisible();
  224 |         await button.focus();
  225 |         await page.keyboard.press("Enter");
  226 |         await expect.poll(() => selections(page)).toContainEqual({source: "user", identity, result});
  227 |         await expect(button).toHaveAttribute("aria-pressed", "true");
  228 |         await refreshDataset(session.host);
  229 |         await expect.poll(() => selections(page)).toHaveLength(1);
  230 |         await expect(session.host.locator('[part=data] tbody button[aria-pressed="true"]')).toHaveCount(1);
  231 |         const selectedIdentity = await session.host.evaluate((element) => (element as VisualizationHost & {selectedIdentity?: string}).selectedIdentity);
  232 |         expect(selectedIdentity).toBe(identity);
  233 |         const selectedRow = session.host.locator('[part=data] tbody tr:has(button[aria-pressed="true"])');
  234 |         await expect(selectedRow).toContainText(rowText);
  235 |         const selectedRowIndex = await selectedRow.evaluate((row) => [...(row.parentElement?.children ?? [])].indexOf(row));
  236 |         expect(selectedRowIndex).toBe(reorderedIndex);
  237 |         await assertBoundedGeometry(session.host);
  238 |         const axe = await new AxeBuilder({page}).include(`#fixture aeliqo-${id}`).analyze();
  239 |         expect(axe.violations).toEqual([]);
  240 |         expect(session.errors).toEqual([]);
  241 |       });
  242 |     }
  243 | 
  244 |     for (const id of VISUALIZATIONS) {
  245 |       test(`${id} keeps the existing partial and empty data states honest`, async ({page}) => {
  246 |         const session = await openVisualization(page, id, variant);
  247 |         await setVisualizationState(session.host, "partial");
  248 |         await expect(session.host.locator("[part=scope]")).toContainText("Partial");
  249 |         await setVisualizationState(session.host, "empty");
  250 |         const status = session.host.locator('[role="status"]').first();
  251 |         await expect(status).toBeVisible();
  252 |         if ((CARTESIAN as readonly string[]).includes(id)) {
  253 |           await expect(status).toContainText(`No ${id} visualization is available.`);
  254 |         } else if ((TEMPORAL as readonly string[]).includes(id)) {
  255 |           await expect(status).toContainText("No matching visualization is available.");
  256 |         } else {
  257 |           await expect(status).toContainText(`This surface requires a ${id} specification.`);
  258 |         }
  259 |         // Visualization elements have no generic status/loading/error property.
  260 |         // Loading and error remain host/materialization concerns covered by the
  261 |         // existing state suite; this matrix does not invent unsupported props.
  262 |         expect(session.errors).toEqual([]);
  263 |       });
  264 |     }
  265 |   });
  266 | }
  267 | 
  268 | for (const id of ["trend", "timeline", "tree"] as const) {
  269 |   for (const variant of VARIANTS) {
  270 |     test(`${id} ${variant} paginates 30 rows while retaining a bounded data-only path`, async ({page}) => {
  271 |       const session = await openVisualization(page, id, variant);
  272 |       await setBoundedRows(session.host, id);
  273 |       await expect(session.host.locator("svg")).toHaveCount(0);
  274 |       await expect(session.host.locator('tbody tr')).toHaveCount(25);
  275 |       await expect(session.host.locator('[role="status"]')).toContainText(/budget|density/i);
  276 |       const next = session.host.getByRole("button", {name: "Next", exact: true});
  277 |       await expect(next).toBeEnabled();
  278 |       await next.click();
> 279 |       await expect(session.host.locator("tbody tr")).toHaveCount(5);
      |                                                      ^ Error: expect(locator).toHaveCount(expected) failed
  280 |       await expect(session.host).toContainText("Rows 26–30 of 30");
  281 |       const pageTwo = await renderedRowCells(session.host);
  282 |       expect(pageTwo[0]?.[1]).toBe(id === "tree" ? "node-25" : "row-25");
  283 |       expect(pageTwo.at(-1)?.[1]).toBe(id === "tree" ? "node-29" : "row-29");
  284 |       await session.host.getByRole("button", {name: "Previous", exact: true}).click();
  285 |       await expect(session.host.locator("tbody tr")).toHaveCount(25);
  286 |       const pageOne = await renderedRowCells(session.host);
  287 |       expect(pageOne[0]?.[1]).toBe(id === "tree" ? "root" : "row-0");
  288 |       expect(pageOne.at(-1)?.[1]).toBe(id === "tree" ? "node-24" : "row-24");
  289 |       await expect(session.host.locator('[role="status"]')).toContainText(/budget|density/i);
  290 |       expect(session.errors).toEqual([]);
  291 |     });
  292 |   }
  293 | }
  294 | 
```