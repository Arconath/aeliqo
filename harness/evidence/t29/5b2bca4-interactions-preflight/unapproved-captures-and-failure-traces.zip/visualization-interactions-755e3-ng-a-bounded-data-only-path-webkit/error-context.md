# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visualization-interactions.spec.ts >> timeline desktop-light paginates 30 rows while retaining a bounded data-only path
- Location: tests/visual/visualization-interactions.spec.ts:270:9

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('#fixture aeliqo-timeline').first().locator('tbody tr')
Expected: 5
Received: 25
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('#fixture aeliqo-timeline').first().locator('tbody tr') with timeout 5000ms
  - waiting for locator('#fixture aeliqo-timeline').first().locator('tbody tr')
    14 × locator resolved to 25 elements
       - unexpected value "25"

```

# Page snapshot

```yaml
- main [ref=e2]:
  - heading "Timeline" [level=1] [ref=e3]
  - figure "Catalog example" [ref=e7]:
    - paragraph [ref=e9]: Complete result. 30 loaded rows.
    - status [ref=e10]: Timeline mark budget exceeded; all loaded intervals remain in the data table.
    - 'region "Catalog example: scrollable data" [ref=e11]':
      - table [ref=e12]:
        - caption [ref=e13]: "Catalog example: exact loaded values"
        - rowgroup [ref=e14]:
          - row [ref=e15]:
            - columnheader "Select" [ref=e16]
            - columnheader "ID" [ref=e17]
            - columnheader "Name" [ref=e18]
            - columnheader "Team" [ref=e19]
            - columnheader "Date" [ref=e20]
            - columnheader "Amount" [ref=e21]
            - columnheader "Bin start" [ref=e22]
            - columnheader "Bin end" [ref=e23]
            - columnheader "Baseline" [ref=e24]
        - rowgroup [ref=e25]:
          - row [ref=e26]:
            - cell [ref=e27]:
              - button "Select row-0" [ref=e28]: Select
            - cell "row-0" [ref=e29]
            - cell "Person 0" [ref=e30]
            - cell "Research" [ref=e31]
            - cell "2026-09-01" [ref=e32]
            - cell "1" [ref=e33]
            - cell "0" [ref=e34]
            - cell "1" [ref=e35]
            - cell "0" [ref=e36]
          - row [ref=e37]:
            - cell [ref=e38]:
              - button "Select row-1" [ref=e39]: Select
            - cell "row-1" [ref=e40]
            - cell "Person 1" [ref=e41]
            - cell "Product" [ref=e42]
            - cell "2026-09-02" [ref=e43]
            - cell "2" [ref=e44]
            - cell "1" [ref=e45]
            - cell "2" [ref=e46]
            - cell "0" [ref=e47]
          - row [ref=e48]:
            - cell [ref=e49]:
              - button "Select row-2" [ref=e50]: Select
            - cell "row-2" [ref=e51]
            - cell "Person 2" [ref=e52]
            - cell "Research" [ref=e53]
            - cell "2026-09-03" [ref=e54]
            - cell "3" [ref=e55]
            - cell "2" [ref=e56]
            - cell "3" [ref=e57]
            - cell "0" [ref=e58]
          - row [ref=e59]:
            - cell [ref=e60]:
              - button "Select row-3" [ref=e61]: Select
            - cell "row-3" [ref=e62]
            - cell "Person 3" [ref=e63]
            - cell "Product" [ref=e64]
            - cell "2026-09-04" [ref=e65]
            - cell "4" [ref=e66]
            - cell "3" [ref=e67]
            - cell "4" [ref=e68]
            - cell "0" [ref=e69]
          - row [ref=e70]:
            - cell [ref=e71]:
              - button "Select row-4" [ref=e72]: Select
            - cell "row-4" [ref=e73]
            - cell "Person 4" [ref=e74]
            - cell "Research" [ref=e75]
            - cell "2026-09-05" [ref=e76]
            - cell "5" [ref=e77]
            - cell "4" [ref=e78]
            - cell "5" [ref=e79]
            - cell "0" [ref=e80]
          - row [ref=e81]:
            - cell [ref=e82]:
              - button "Select row-5" [ref=e83]: Select
            - cell "row-5" [ref=e84]
            - cell "Person 5" [ref=e85]
            - cell "Product" [ref=e86]
            - cell "2026-09-06" [ref=e87]
            - cell "6" [ref=e88]
            - cell "5" [ref=e89]
            - cell "6" [ref=e90]
            - cell "0" [ref=e91]
          - row [ref=e92]:
            - cell [ref=e93]:
              - button "Select row-6" [ref=e94]: Select
            - cell "row-6" [ref=e95]
            - cell "Person 6" [ref=e96]
            - cell "Research" [ref=e97]
            - cell "2026-09-07" [ref=e98]
            - cell "7" [ref=e99]
            - cell "6" [ref=e100]
            - cell "7" [ref=e101]
            - cell "0" [ref=e102]
          - row [ref=e103]:
            - cell [ref=e104]:
              - button "Select row-7" [ref=e105]: Select
            - cell "row-7" [ref=e106]
            - cell "Person 7" [ref=e107]
            - cell "Product" [ref=e108]
            - cell "2026-09-08" [ref=e109]
            - cell "8" [ref=e110]
            - cell "7" [ref=e111]
            - cell "8" [ref=e112]
            - cell "0" [ref=e113]
          - row [ref=e114]:
            - cell [ref=e115]:
              - button "Select row-8" [ref=e116]: Select
            - cell "row-8" [ref=e117]
            - cell "Person 8" [ref=e118]
            - cell "Research" [ref=e119]
            - cell "2026-09-09" [ref=e120]
            - cell "9" [ref=e121]
            - cell "8" [ref=e122]
            - cell "9" [ref=e123]
            - cell "0" [ref=e124]
          - row [ref=e125]:
            - cell [ref=e126]:
              - button "Select row-9" [ref=e127]: Select
            - cell "row-9" [ref=e128]
            - cell "Person 9" [ref=e129]
            - cell "Product" [ref=e130]
            - cell "2026-09-10" [ref=e131]
            - cell "10" [ref=e132]
            - cell "9" [ref=e133]
            - cell "10" [ref=e134]
            - cell "0" [ref=e135]
          - row [ref=e136]:
            - cell [ref=e137]:
              - button "Select row-10" [ref=e138]: Select
            - cell "row-10" [ref=e139]
            - cell "Person 10" [ref=e140]
            - cell "Research" [ref=e141]
            - cell "2026-09-11" [ref=e142]
            - cell "11" [ref=e143]
            - cell "10" [ref=e144]
            - cell "11" [ref=e145]
            - cell "0" [ref=e146]
          - row [ref=e147]:
            - cell [ref=e148]:
              - button "Select row-11" [ref=e149]: Select
            - cell "row-11" [ref=e150]
            - cell "Person 11" [ref=e151]
            - cell "Product" [ref=e152]
            - cell "2026-09-12" [ref=e153]
            - cell "12" [ref=e154]
            - cell "11" [ref=e155]
            - cell "12" [ref=e156]
            - cell "0" [ref=e157]
          - row [ref=e158]:
            - cell [ref=e159]:
              - button "Select row-12" [ref=e160]: Select
            - cell "row-12" [ref=e161]
            - cell "Person 12" [ref=e162]
            - cell "Research" [ref=e163]
            - cell "2026-09-13" [ref=e164]
            - cell "13" [ref=e165]
            - cell "12" [ref=e166]
            - cell "13" [ref=e167]
            - cell "0" [ref=e168]
          - row [ref=e169]:
            - cell [ref=e170]:
              - button "Select row-13" [ref=e171]: Select
            - cell "row-13" [ref=e172]
            - cell "Person 13" [ref=e173]
            - cell "Product" [ref=e174]
            - cell "2026-09-14" [ref=e175]
            - cell "14" [ref=e176]
            - cell "13" [ref=e177]
            - cell "14" [ref=e178]
            - cell "0" [ref=e179]
          - row [ref=e180]:
            - cell [ref=e181]:
              - button "Select row-14" [ref=e182]: Select
            - cell "row-14" [ref=e183]
            - cell "Person 14" [ref=e184]
            - cell "Research" [ref=e185]
            - cell "2026-09-15" [ref=e186]
            - cell "15" [ref=e187]
            - cell "14" [ref=e188]
            - cell "15" [ref=e189]
            - cell "0" [ref=e190]
          - row [ref=e191]:
            - cell [ref=e192]:
              - button "Select row-15" [ref=e193]: Select
            - cell "row-15" [ref=e194]
            - cell "Person 15" [ref=e195]
            - cell "Product" [ref=e196]
            - cell "2026-09-16" [ref=e197]
            - cell "16" [ref=e198]
            - cell "15" [ref=e199]
            - cell "16" [ref=e200]
            - cell "0" [ref=e201]
          - row [ref=e202]:
            - cell [ref=e203]:
              - button "Select row-16" [ref=e204]: Select
            - cell "row-16" [ref=e205]
            - cell "Person 16" [ref=e206]
            - cell "Research" [ref=e207]
            - cell "2026-09-17" [ref=e208]
            - cell "17" [ref=e209]
            - cell "16" [ref=e210]
            - cell "17" [ref=e211]
            - cell "0" [ref=e212]
          - row [ref=e213]:
            - cell [ref=e214]:
              - button "Select row-17" [ref=e215]: Select
            - cell "row-17" [ref=e216]
            - cell "Person 17" [ref=e217]
            - cell "Product" [ref=e218]
            - cell "2026-09-18" [ref=e219]
            - cell "18" [ref=e220]
            - cell "17" [ref=e221]
            - cell "18" [ref=e222]
            - cell "0" [ref=e223]
          - row [ref=e224]:
            - cell [ref=e225]:
              - button "Select row-18" [ref=e226]: Select
            - cell "row-18" [ref=e227]
            - cell "Person 18" [ref=e228]
            - cell "Research" [ref=e229]
            - cell "2026-09-19" [ref=e230]
            - cell "19" [ref=e231]
            - cell "18" [ref=e232]
            - cell "19" [ref=e233]
            - cell "0" [ref=e234]
          - row [ref=e235]:
            - cell [ref=e236]:
              - button "Select row-19" [ref=e237]: Select
            - cell "row-19" [ref=e238]
            - cell "Person 19" [ref=e239]
            - cell "Product" [ref=e240]
            - cell "2026-09-20" [ref=e241]
            - cell "20" [ref=e242]
            - cell "19" [ref=e243]
            - cell "20" [ref=e244]
            - cell "0" [ref=e245]
          - row [ref=e246]:
            - cell [ref=e247]:
              - button "Select row-20" [ref=e248]: Select
            - cell "row-20" [ref=e249]
            - cell "Person 20" [ref=e250]
            - cell "Research" [ref=e251]
            - cell "2026-09-21" [ref=e252]
            - cell "21" [ref=e253]
            - cell "20" [ref=e254]
            - cell "21" [ref=e255]
            - cell "0" [ref=e256]
          - row [ref=e257]:
            - cell [ref=e258]:
              - button "Select row-21" [ref=e259]: Select
            - cell "row-21" [ref=e260]
            - cell "Person 21" [ref=e261]
            - cell "Product" [ref=e262]
            - cell "2026-09-22" [ref=e263]
            - cell "22" [ref=e264]
            - cell "21" [ref=e265]
            - cell "22" [ref=e266]
            - cell "0" [ref=e267]
          - row [ref=e268]:
            - cell [ref=e269]:
              - button "Select row-22" [ref=e270]: Select
            - cell "row-22" [ref=e271]
            - cell "Person 22" [ref=e272]
            - cell "Research" [ref=e273]
            - cell "2026-09-23" [ref=e274]
            - cell "23" [ref=e275]
            - cell "22" [ref=e276]
            - cell "23" [ref=e277]
            - cell "0" [ref=e278]
          - row [ref=e279]:
            - cell [ref=e280]:
              - button "Select row-23" [ref=e281]: Select
            - cell "row-23" [ref=e282]
            - cell "Person 23" [ref=e283]
            - cell "Product" [ref=e284]
            - cell "2026-09-24" [ref=e285]
            - cell "24" [ref=e286]
            - cell "23" [ref=e287]
            - cell "24" [ref=e288]
            - cell "0" [ref=e289]
          - row [ref=e290]:
            - cell [ref=e291]:
              - button "Select row-24" [ref=e292]: Select
            - cell "row-24" [ref=e293]
            - cell "Person 24" [ref=e294]
            - cell "Research" [ref=e295]
            - cell "2026-09-25" [ref=e296]
            - cell "25" [ref=e297]
            - cell "24" [ref=e298]
            - cell "25" [ref=e299]
            - cell "0" [ref=e300]
    - navigation "Visualization data pages" [ref=e301]:
      - button "Previous" [disabled] [ref=e302]
      - generic [ref=e303]: Rows 1–25 of 30
      - button "Next" [ref=e304]
```

# Test source

```ts
  179 |   if (id === "hierarchy") {
  180 |     return Array.from({length: count}, (_, index) => index === 0
  181 |       ? {id: "root", parent: null, label: "Root", amount: count}
  182 |       : {id: `node-${index}`, parent: "root", label: `Node ${index}`, amount: index});
  183 |   }
  184 |   return Array.from({length: count}, (_, index) => {
  185 |     const date = new Date(Date.UTC(2026, 8, 1 + index)).toISOString().slice(0, 10);
  186 |     return {
  187 |       id: `row-${index}`,
  188 |       name: `Person ${index}`,
  189 |       team: index % 2 === 0 ? "Research" : "Product",
  190 |       date,
  191 |       amount: index + 1,
  192 |       low: index,
  193 |       high: index + 1,
  194 |       zero: 0,
  195 |     };
  196 |   });
  197 | }
  198 | 
  199 | async function setBoundedRows(host: Locator, id: "trend" | "timeline" | "tree"): Promise<void> {
  200 |   const rows = rowsFor(id === "tree" ? "hierarchy" : id === "timeline" ? "temporal" : "cartesian", 30);
  201 |   await host.evaluate(async (element, nextRows) => {
  202 |     const view = element as VisualizationHost;
  203 |     const result = view.context.results[0]!;
  204 |     view.context = {
  205 |       ...view.context,
  206 |       results: view.context.results.map((candidate, index) => index === 0
  207 |         ? {...candidate, counts: {...(candidate as unknown as {readonly counts: Record<string, unknown>}).counts, loaded: nextRows.length}}
  208 |         : candidate),
  209 |     } as VisualizationHost["context"];
  210 |     view.datasets = [{result: result.ref, rows: nextRows}];
  211 |     view.maxMarks = 1;
  212 |     await view.updateComplete;
  213 |   }, rows);
  214 | }
  215 | 
  216 | for (const variant of VARIANTS) {
  217 |   test.describe(`${variant} visualization interactions`, () => {
  218 |     for (const id of VISUALIZATIONS) {
  219 |       test(`${id} selects a stable identity with exact result lineage`, async ({page}) => {
  220 |         const session = await openVisualization(page, id, variant);
  221 |         const {identity, result, rowText, reorderedIndex} = expectedSelection[id];
  222 |         const button = session.host.locator("[part=data] tbody button").first();
  223 |         await expect(button).toBeVisible();
  224 |         await button.focus();
  225 |         await page.keyboard.press("Enter");
  226 |         await expect.poll(() => selections(page)).toContainEqual({source: "user", identity, result});
  227 |         await expect(button).toHaveAttribute("aria-pressed", "true");
  228 |         await refreshDataset(session.host);
  229 |         await expect.poll(() => selections(page)).toHaveLength(1);
  230 |         await expect(session.host.locator('[part=data] tbody button[aria-pressed="true"]')).toHaveCount(1);
  231 |         const selectedIdentity = await session.host.evaluate((element) => (element as VisualizationHost & {selectedIdentity?: string}).selectedIdentity);
  232 |         expect(selectedIdentity).toBe(identity);
  233 |         const selectedRow = session.host.locator('[part=data] tbody tr:has(button[aria-pressed="true"])');
  234 |         await expect(selectedRow).toContainText(rowText);
  235 |         const selectedRowIndex = await selectedRow.evaluate((row) => [...(row.parentElement?.children ?? [])].indexOf(row));
  236 |         expect(selectedRowIndex).toBe(reorderedIndex);
  237 |         await assertBoundedGeometry(session.host);
  238 |         const axe = await new AxeBuilder({page}).include(`#fixture aeliqo-${id}`).analyze();
  239 |         expect(axe.violations).toEqual([]);
  240 |         expect(session.errors).toEqual([]);
  241 |       });
  242 |     }
  243 | 
  244 |     for (const id of VISUALIZATIONS) {
  245 |       test(`${id} keeps the existing partial and empty data states honest`, async ({page}) => {
  246 |         const session = await openVisualization(page, id, variant);
  247 |         await setVisualizationState(session.host, "partial");
  248 |         await expect(session.host.locator("[part=scope]")).toContainText("Partial");
  249 |         await setVisualizationState(session.host, "empty");
  250 |         const status = session.host.locator('[role="status"]').first();
  251 |         await expect(status).toBeVisible();
  252 |         if ((CARTESIAN as readonly string[]).includes(id)) {
  253 |           await expect(status).toContainText(`No ${id} visualization is available.`);
  254 |         } else if ((TEMPORAL as readonly string[]).includes(id)) {
  255 |           await expect(status).toContainText("No matching visualization is available.");
  256 |         } else {
  257 |           await expect(status).toContainText(`This surface requires a ${id} specification.`);
  258 |         }
  259 |         // Visualization elements have no generic status/loading/error property.
  260 |         // Loading and error remain host/materialization concerns covered by the
  261 |         // existing state suite; this matrix does not invent unsupported props.
  262 |         expect(session.errors).toEqual([]);
  263 |       });
  264 |     }
  265 |   });
  266 | }
  267 | 
  268 | for (const id of ["trend", "timeline", "tree"] as const) {
  269 |   for (const variant of VARIANTS) {
  270 |     test(`${id} ${variant} paginates 30 rows while retaining a bounded data-only path`, async ({page}) => {
  271 |       const session = await openVisualization(page, id, variant);
  272 |       await setBoundedRows(session.host, id);
  273 |       await expect(session.host.locator("svg")).toHaveCount(0);
  274 |       await expect(session.host.locator('tbody tr')).toHaveCount(25);
  275 |       await expect(session.host.locator('[role="status"]')).toContainText(/budget|density/i);
  276 |       const next = session.host.getByRole("button", {name: "Next", exact: true});
  277 |       await expect(next).toBeEnabled();
  278 |       await next.click();
> 279 |       await expect(session.host.locator("tbody tr")).toHaveCount(5);
      |                                                      ^ Error: expect(locator).toHaveCount(expected) failed
  280 |       await expect(session.host).toContainText("Rows 26–30 of 30");
  281 |       const pageTwo = await renderedRowCells(session.host);
  282 |       expect(pageTwo[0]?.[1]).toBe(id === "tree" ? "node-25" : "row-25");
  283 |       expect(pageTwo.at(-1)?.[1]).toBe(id === "tree" ? "node-29" : "row-29");
  284 |       await session.host.getByRole("button", {name: "Previous", exact: true}).click();
  285 |       await expect(session.host.locator("tbody tr")).toHaveCount(25);
  286 |       const pageOne = await renderedRowCells(session.host);
  287 |       expect(pageOne[0]?.[1]).toBe(id === "tree" ? "root" : "row-0");
  288 |       expect(pageOne.at(-1)?.[1]).toBe(id === "tree" ? "node-24" : "row-24");
  289 |       await expect(session.host.locator('[role="status"]')).toContainText(/budget|density/i);
  290 |       expect(session.errors).toEqual([]);
  291 |     });
  292 |   }
  293 | }
  294 | 
```